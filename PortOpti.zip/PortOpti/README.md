# User Guide
## Configuration File
Under the `portopti` directory, there is a json file called `net_config.json`,
 holding all the configuration of the agent and could be modified outside the program code.

## Training and Tuning the hyper-parameters
1. First, modify the `net_config.json` file.
2. make sure current directory is under `FYP-Final` and type `python main.py --mode=generate --repeat=1`
    * this will make 1 subfolders under the `train_package`
    * in each subfolder, there is a copy of the `net_config.json`
    * `--repeat=n`, n could followed by any positive integers. The random seed of each the subfolder is from 0 to n-1 sequentially.
      * Notably, random seed could also affect the performance in a large scale.
3. type `python main.py --mode=train --processes=1`
    * this will start training one by one of the n folder created just now

## Back-test
*Note: Before back-testing, you need to suceessfully finish training of algo first*
* Type `python main.py --mode=backtest --algo=1` to execute
backtest with rolling train on the target model.