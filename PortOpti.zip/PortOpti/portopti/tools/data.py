from __future__ import division,absolute_import,print_function
import numpy as np
import pandas as pd
import xarray as xr

# Create an empty Xarray DataArray to serve as our 3D tensor.
def create_data_array(features, stocks, time_index):
    # Convert coordinates to lists to ensure proper shape inference.
    features = list(features)
    stocks = list(stocks)
    return xr.DataArray(
        data=np.full((len(features), len(stocks), len(time_index)), np.nan, dtype=np.float32),
        dims=["feature", "stock", "time"],
        coords={"feature": features, "stock": stocks, "time": time_index}
    )

def data_array_fillna(data_array, method="both"):
    """
    Fill NaN values in an Xarray DataArray along the 'time' dimension.
    
    Parameters:
      data_array (xr.DataArray): The data array to fill.
      method (str): The filling method. Options:
          - "bfill": Backward fill along 'time'.
          - "ffill": Forward fill along 'time'.
          - "both": Apply backward fill then forward fill.
    
    Returns:
      xr.DataArray: The filled data array.
    """
    if method == "both":
        filled = data_array.bfill(dim="time").ffill(dim="time")
    elif method == "bfill":
        filled = data_array.bfill(dim="time")
    elif method == "ffill":
        filled = data_array.ffill(dim="time")
    else:
        raise ValueError("Unsupported fill method: {}".format(method))
    return filled

def get_type_list(feature_number):
    """Map feature count to engineered features"""
    feature_sets = {
        1: ["returns"],
        2: ["returns", "norm_volume"],
        3: ["returns", "rel_high", "rel_low"],
        4: ["returns", "norm_volume", "MA_ratio", "volatility"],
        6: ["returns", "norm_volume", "rel_high", "rel_low", "MA_ratio", "volatility"]
    }
    
    try:
        return feature_sets[feature_number]
    except KeyError:
        raise ValueError(f"Feature number {feature_number} not supported. "
                         f"Valid options: {list(feature_sets.keys())}")


def get_volume_forward(time_span, portion, portion_reversed):
    volume_forward = 0
    if not portion_reversed:
        volume_forward = time_span*portion
    return volume_forward

